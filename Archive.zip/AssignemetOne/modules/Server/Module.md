Prints "Hello, World!" with a main function.
[//]: # (above is the module summary)

# Module Overview
Provides an overview about the module when generating the API documentations.
For example, refer to https://lib.ballerina.io/ballerina/io/latest
